//we should put in environment variable

module.exports = {
    'secret': 'supersecret'
  };