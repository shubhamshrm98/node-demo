var mongoose = require("mongoose");

// var Employee = mongoose.model("Employee");

var Employee = require("../models/Employee");

var employeeController = {};


employeeController.landing = function(req, res) {
  Employee.find({}).exec(function (err, employees) {
    if (err) {
      console.log("Error:", err);
    }
    else {
      res.render("../views/employees/landingPage", {employees: employees});
    }
  });
};

employeeController.adminLogin = function(req, res) {
  Employee.find({}).exec(function (err, employees) {
    if (err) {
      console.log("Error:", err);
    }
    else {
      res.render("../views/login/adminLogin", {employees: employees});
    }
  });
};

employeeController.unauthorizedUser = function(req, res) {
  Employee.find({}).exec(function (err, employees) {
    if (err) {
      console.log("Error:", err);
    }
    else {
      res.render("../views/unauthorization/delete", {employees: employees});
    }
  });
};

employeeController.unauthorizedAdmin = function(req, res) {
  Employee.find({}).exec(function (err, employees) {
    if (err) {
      console.log("Error:", err);
    }
    else {
      res.render("../views/unauthorization/edit", {employees: employees});
    }
  });
};

employeeController.duplicateEntry = function(req, res) {
  Employee.find({}).exec(function (err, employees) {
    if (err) {
      console.log("Error:", err);
    }
    else {
      res.render("../views/unauthorization/duplicateEntry", {employees: employees});
    }
  });
};

// Add show list of employees function.

employeeController.list = function(req, res) {
  Employee.find({}).exec(function (err, employees) {
    if (err) {
      console.log("Error:", err);
    }
    else {
      res.render("../views/employees/index", {employees: employees});
    }
  });
};
// Add show single employee by id function.

employeeController.show = function(req, res) {
  Employee.findOne({_id: req.params.id}).exec(function (err, employee) {
    if (err) {
      console.log("Error:", err);
    }
    else {
      res.render("../views/employees/show", {employee: employee});
    }
  });
};
// Add create employee function, it just redirects to create the page.

employeeController.create = function(req, res) {
  res.render("../views/employees/create");
};
// Add save new employee function.

employeeController.save = function(req, res) {
  var employee = new Employee(req.body);

  employee.save(function(err) {
    if(err) {
      console.log(err);
      // res.render("../views/employees/create");
      res.redirect("/api/v1/duplicateEntry");
    } else {
      console.log("Successfully created an employee.");
      res.redirect("/api/v1/show/"+employee._id);
    }
  });
};
// Add edit employee by id function, it just redirects to edit page.

employeeController.edit = function(req, res) {
  Employee.findOne({_id: req.params.id}).exec(function (err, employee) {
    if (err) {
      console.log("Error:", err);
    }
    else {
      res.render("../views/employees/edit", {employee: employee});
    }
  });
};
// Add update employee function for updating currently edited employee.

// employeeController.update = function(req, res) {
//   Employee.findByIdAndUpdate(req.params.id, { $set: { name: req.body.name, emailID: req.body.emailID, phoneNo: req.body.phoneNo, role: req.body.role }}, { new: true }, function (err, employee) {
//     if (err) {
//       console.log(err);
//       res.render("../views/employees/edit", {employee: req.body});
//     }
//     res.redirect("/api/v1/show/"+employee._id);
//   });
// };

employeeController.update = function(req, res) {
  Employee.find({_id:req.params.id },function(err,user){
    user.forEach(element => {
    if(element.role ==="user")
    {
        Employee.findByIdAndUpdate(req.params.id, { $set: { name: req.body.name, emailID: req.body.emailID, phoneNo: req.body.phoneNo, role: req.body.role }}, { new: true }, function (err, employee) {
        if (err) 
        {  
          console.log(err);
          res.render("../views/employees/edit", {employee: req.body});
        }
        else
        {
          res.redirect("/api/v1/list");
        }
     });
    }
    else
    {
     res.redirect("/api/v1/unauthorizedAdmin");
    }
})
});

};

// Add delete employee by id function for remove single employee data.

// employeeController.delete = function(req, res) {
//   Employee.remove({_id: req.params.id}, function(err) {
//     if(err) {
//       console.log(err);
//     }
//     else {
//       console.log("Employee deleted!");
//       res.redirect("/api/v1");
//     }
//   });
// };


employeeController.delete = function(req, res) {
  
  Employee.find({_id:req.params.id },function(err,user){
  user.forEach(element => {
    
  if(element.role ==="admin"){
  Employee.remove({_id: req.params.id}, function(err) {
    if(err) {
      console.log(err);
    }
    else {
      console.log("Employee deleted!");
      res.redirect("/api/v1");
      console.log('Running after');
    }
  });
}
  else{
    res.redirect("/api/v1/unauthorizedUser");
  }
})
  });

};


// Finally, export employee controller as a module.

module.exports = employeeController;