var express = require('express');
var router = express.Router();

var employee = require("../controllers/EmployeeController.js");

// Get all employees
router.get('/', employee.landing);

// Lnding Page
router.get('/list', employee.list)

// Get single employee by id
router.get('/show/:id', employee.show);

// Create employee
router.get('/create', employee.create);

// Save employee
router.post('/save', employee.save);

// Edit employee
router.get('/edit/:id', employee.edit);

// Edit update
router.post('/update/:id', employee.update);

// Edit update
router.post('/delete/:id', employee.delete);


router.get('/landingPage/adminLogin', employee.adminLogin)

router.get('/unauthorizedUser', employee.unauthorizedUser)

router.get('/duplicateEntry', employee.duplicateEntry)

router.get('/unauthorizedAdmin', employee.unauthorizedAdmin)



module.exports = router;
